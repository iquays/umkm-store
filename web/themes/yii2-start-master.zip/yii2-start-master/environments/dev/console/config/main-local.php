<?php
return [
    'params' => require(__DIR__ . '/params-local.php')
];
